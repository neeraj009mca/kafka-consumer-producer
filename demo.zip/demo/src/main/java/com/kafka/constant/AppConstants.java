package com.kafka.constant;

public class AppConstants {
    public static final String TOPIC_NAME = "firstTopic";
    public static final String GROUP_ID = "kafka-app";
}